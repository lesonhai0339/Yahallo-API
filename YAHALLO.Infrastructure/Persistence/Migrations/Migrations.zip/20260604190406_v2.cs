﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace YAHALLO.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class v2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
      name: "LastChapterIndex",
      table: "Manga",
      type: "int",
      nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "LastChapterId",
                table: "Manga",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastChapterUpdate",
                table: "Manga",
                type: "datetime2",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Manga_LastChapterId",
                table: "Manga",
                column: "LastChapterId");

            migrationBuilder.AddForeignKey(
                name: "FK_Manga_Chapter_LastChapterId",
                table: "Manga",
                column: "LastChapterId",
                principalTable: "Chapter",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "MangaEntityId",
                table: "Image",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Image_MangaEntityId",
                table: "Image",
                column: "MangaEntityId");

            migrationBuilder.AddForeignKey(
                name: "FK_Image_Manga_MangaEntityId",
                table: "Image",
                column: "MangaEntityId",
                principalTable: "Manga",
                principalColumn: "Id");
        }
    }
}
